# Hotspot-Maker
This plugin allows us to mark hotspots on image in background
